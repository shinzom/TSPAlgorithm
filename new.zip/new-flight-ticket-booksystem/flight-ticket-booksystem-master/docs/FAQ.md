# FAQ

## 如何添加一个新航班？

启动应用后，进入 admin 后台管理页面 http://localhost:8000/booksystem/admin/booksystem/flight/

![](../assets/admin_flights.png)

添加机票信息

![](../assets/admin_flights_add.png)